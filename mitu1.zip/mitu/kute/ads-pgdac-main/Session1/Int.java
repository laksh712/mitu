import java.util.Scanner;
import java.lang.Math;
class Int {
	public static void main(String args[]) {
	byte x = 300;
		//for(byte i=0; ; i++)
				System.out.println(x);
	}
}
