class Prog {
	public static void main(String a[])
	{
		byte num = 200;
		//for(byte num=0; num<200; num++)
			System.out.println(num);
	}
}
