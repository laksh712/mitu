package graph.undirected.unweighted.adjacencyMatrix.core;

public class GraphCustomException extends Exception {

	public GraphCustomException(String errMsg)
	{
		super(errMsg);
		// TODO Auto-generated constructor stub
	}
}
