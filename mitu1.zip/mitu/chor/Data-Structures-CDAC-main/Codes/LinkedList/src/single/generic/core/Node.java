package single.generic.core;

public class Node<E> {

	E data;
	Node<E> next;
	
}
