package com.nongeneric.arraystack.core;

public interface StackInterface<T> {

	int[] arr = new int[10];
	int top = -1;
	
//	void push(<? extends E>);
	
}
